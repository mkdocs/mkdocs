---
template: overrides/main.html
---

# License

**MIT License**

--8<-- "LICENSE"

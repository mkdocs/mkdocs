## Deprecated

For new projects, use [Sphinx](https://www.sphinx-doc.org/) with [recommonmark](https://github.com/readthedocs/recommonmark).


# Alabaster for MkDocs

1. `pip install mkdocs-alabaster`
2. Add to your mkdocs.yml: `theme: alabaster`

Documentation: <http://mkdocs-alabaster.ale.sh>

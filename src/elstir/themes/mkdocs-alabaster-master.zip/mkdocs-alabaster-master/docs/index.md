## Deprecated

For new projects, use [Sphinx](https://www.sphinx-doc.org/) with [recommonmark](https://github.com/readthedocs/recommonmark).


Alabaster for MkDocs
=====================

Original Alabaster is a visually (c)lean, responsive, configurable theme for the Sphinx documentation system. It began as a third-party theme, but as of Sphinx 1.3, Alabaster is an install-time dependency of Sphinx and is selected as the default theme, and is used in projects such as <http://paramiko.org/>, <http://fabfile.org/> or <http://pyinvoke.org/>.

This is a port of Alabaster for the [MkDocs](http://www.mkdocs.org/) static site generator.


## Features

- Navigation and TOC
- Search
- Customizable sidebar (planned)
